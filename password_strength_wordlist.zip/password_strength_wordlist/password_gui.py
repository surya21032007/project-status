# password_gui.py

import tkinter as tk
from tkinter import messagebox
from zxcvbn import zxcvbn
from itertools import permutations
import re

def leetspeak(word):
    return word.replace('a', '@').replace('e', '3').replace('i', '1').replace('o', '0').replace('s', '$')

def generate_wordlist(data):
    words = list(data.values())
    variations = []

    for word in words:
        variations.extend([
            word.lower(), word.upper(), word.capitalize(),
            word + "123", word + "@2024", word[::-1],
            leetspeak(word)
        ])

    for i in range(2, len(words)+1):
        for combo in permutations(words, i):
            joined = "".join(combo)
            variations.append(joined)
            variations.append(leetspeak(joined))

    years = [str(y) for y in range(2000, 2026)]
    extended = []
    for word in variations:
        for year in years:
            extended.append(word + year)

    variations.extend(extended)
    final_wordlist = list(set(filter(lambda w: re.match(r'^[a-zA-Z0-9@$.]+$', w), variations)))

    with open("enhanced_wordlist.txt", "w") as f:
        for item in final_wordlist:
            f.write(item + "\n")
    
    return len(final_wordlist)

def analyze_password():
    password = entry_password.get()
    if not password:
        messagebox.showwarning("Input Missing", "Please enter a password.")
        return

    result = zxcvbn(password)
    score = result['score']
    crack_time = result['crack_times_display']['offline_slow_hashing_1e4_per_second']
    result_label.config(text=f"Score: {score}/4 | Crack Time: {crack_time}")
    messagebox.showinfo("Done", f"Password analyzed.\nScore: {score}/4\nCrack Time: {crack_time}")

def generate():
    name = entry_name.get()
    dob = entry_dob.get()
    pet = entry_pet.get()

def analyze_password():
    tk.Button(root, text="Analyze Password", command=analyze_password).pack(pady=5)

    password = entry_password.get()
    if not password:
        messagebox.showwarning("Input Missing", "Please enter a password.")
        return

    result = zxcvbn(password)
    score = result['score']
    crack_time = result['crack_times_display']['offline_slow_hashing_1e4_per_second']
    strength_text = ["Very Weak", "Weak", "Moderate", "Strong", "Very Strong"][score]

    result_label.config(text=f"Score: {score}/4 ({strength_text})\nCrack Time: {crack_time}")
    messagebox.showinfo("Done", f"Password analyzed.\nScore: {score}/4\nStrength: {strength_text}\nCrack Time: {crack_time}")

    if not name or not dob or not pet:
        messagebox.showwarning("Input Missing", "Please fill in all fields.")
        return

    data = {"name": name, "dob": dob, "pet": pet}
    count = generate_wordlist(data)
    messagebox.showinfo("Wordlist Generated", f"{count} entries saved to enhanced_wordlist.txt")

# --- GUI Setup ---
root = tk.Tk()
root.title("Password Strength & Wordlist Tool")
root.geometry("400x300")

tk.Label(root, text="Password:").pack()
entry_password = tk.Entry(root, show="*")
entry_password.pack()
tk.Button(root, text="Analyze Password", command=analyze_password).pack()
result_label = tk.Label(root, text="")
result_label.pack(pady=10)

tk.Label(root, text="Name:").pack()
entry_name = tk.Entry(root)
entry_name.pack()
tk.Label(root, text="DOB (YYYY):").pack()
entry_dob = tk.Entry(root)
entry_dob.pack()
tk.Label(root, text="Pet Name:").pack()
entry_pet = tk.Entry(root)
entry_pet.pack()

tk.Button(root, text="Generate Wordlist", command=generate).pack(pady=10)

root.mainloop()
